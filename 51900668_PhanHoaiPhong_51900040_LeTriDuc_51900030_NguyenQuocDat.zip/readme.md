Link video demo: https://www.youtube.com/watch?v=cG5essg7Vaw

Tài khoản đăng nhập App
email: testapptdt@gmail.com
password: testapptdt@123