package freecode.notes.app.Constant;

import java.io.Serializable;

public class Constant implements Serializable {
    private static final long serialVersionUID = 1L;

    public static String company = "TDTU";
    public static String email = "phonglechanh113@gmail.com";
    public static String website = "tdtu.edu.vn";
    public static String contact = "0329334312";
    public static String privacyPolicy = "http://notesapp.com";

    //--------------------Admob ads----------------- //
    public static Boolean isAdmobBannerAd = true;
    public static Boolean  isAdmobInterAd = true;
    public static int adShow = 5;

    //--------------------Fb ads----------------- //
    public static Boolean isFBBannerAd = false;
    public static Boolean  isFBInterAd = false;
    public static int adShowFB = 5;


}